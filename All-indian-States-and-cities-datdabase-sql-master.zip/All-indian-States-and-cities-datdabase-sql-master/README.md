# All-indian-States-and-cities-datdabase-sql

create database "test"..and import this "database.sql" file into it..

this project is under development ..All pull requests will be welcomed.
